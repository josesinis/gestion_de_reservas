<?php
/*
|--------------------------------------------------------------------------
| Sistema     : Gestión Institucional
| Archivo     : auth.php
|--------------------------------------------------------------------------
| Descripción :
| Control centralizado de autenticación y autorización.
|--------------------------------------------------------------------------
*/

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


//=====================================================
// VALIDAR SESIÓN
//=====================================================

function requiereLogin(): void
{
    if (empty($_SESSION['usuario_id'])) {

        $_SESSION['error'] =
            'Debe iniciar sesión para acceder al sistema.';

        header('Location: /gestion_de_reservas/login.php');
        exit();
    }
}


//=====================================================
// OBTENER USUARIO ACTUAL
//=====================================================

function usuarioActual(): ?array
{
    if (empty($_SESSION['usuario_id'])) {
        return null;
    }

    return [
        'id' => (int) $_SESSION['usuario_id'],
        'usuario' => $_SESSION['usuario'] ?? '',
        'nombre' => $_SESSION['nombre_usuario'] ?? '',
        'rol' => $_SESSION['rol'] ?? '',
    ];
}


//=====================================================
// VALIDAR ROL
//=====================================================

function tieneRol(string $rol): bool
{
    return isset($_SESSION['rol'])
        && $_SESSION['rol'] === $rol;
}


//=====================================================
// REQUERIR ROL
//=====================================================

function requiereRol(string $rol): void
{
    requiereLogin();

    if (!tieneRol($rol)) {

        $_SESSION['error'] =
            'No tiene permisos para acceder a esta sección.';

        header('Location: /gestion_de_reservas/agenda.php');
        exit();
    }
}


//=====================================================
// VALIDAR SUPERADMIN
//=====================================================

function esSuperAdmin(): bool
{
    return tieneRol('superadmin');
}


//=====================================================
// REQUERIR SUPERADMIN
//=====================================================

function requiereSuperAdmin(): void
{
    requiereLogin();

    if (!esSuperAdmin()) {

        $_SESSION['error'] =
            'Esta sección requiere permisos de superadmin.';

        header('Location: /gestion_de_reservas/agenda.php');
        exit();
    }
}
