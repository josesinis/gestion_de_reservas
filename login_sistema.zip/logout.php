<?php
/*
|--------------------------------------------------------------------------
| Sistema     : Gestión Institucional
| Archivo     : logout.php
|--------------------------------------------------------------------------
| Descripción :
| Cierra la sesión del usuario.
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/includes/auth.php';


//=====================================================
// CERRAR SESIÓN
//=====================================================

$_SESSION = [];


//=====================================================
// ELIMINAR COOKIE DE SESIÓN
//=====================================================

if (ini_get('session.use_cookies')) {

    $parametros = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        time() - 42000,
        $parametros['path'],
        $parametros['domain'],
        $parametros['secure'],
        $parametros['httponly']
    );
}


//=====================================================
// DESTRUIR SESIÓN
//=====================================================

session_destroy();


//=====================================================
// VOLVER AL LOGIN
//=====================================================

header('Location: /gestion_de_reservas/login.php');
exit();
